import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { useState, useEffect } from "react";
import { playNotificationSound } from "./NotificationSound";
import { Id } from "../convex/_generated/dataModel";

interface Notification {
  _id: Id<"notifications">;
  taskId: Id<"tasks">;
  message: string;
  read: boolean;
  _creationTime: number;
}

export function Notifications() {
  const notifications = useQuery(api.tasks.getNotifications) || [];
  const markAsRead = useMutation(api.tasks.markNotificationAsRead);
  const [isOpen, setIsOpen] = useState(false);
  const [previousCount, setPreviousCount] = useState(0);

  const unreadCount = notifications.filter((n: Notification) => !n.read).length;

  // تشغيل الصوت عند وصول تنبيه جديد
  useEffect(() => {
    if (unreadCount > previousCount) {
      playNotificationSound();
    }
    setPreviousCount(unreadCount);
  }, [unreadCount]);

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-gray-600 hover:text-gray-800 dark:text-gray-300 dark:hover:text-white"
      >
        🔔
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-600 rounded-full">
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden z-50">
          <div className="p-2 border-b dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
              التنبيهات
            </h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <p className="p-4 text-gray-500 dark:text-gray-400 text-center">
                لا توجد تنبيهات
              </p>
            ) : (
              notifications.map((notification: Notification) => (
                <div
                  key={notification._id}
                  className={`p-3 border-b dark:border-gray-700 ${
                    !notification.read
                      ? "bg-blue-50 dark:bg-blue-900/20"
                      : "hover:bg-gray-50 dark:hover:bg-gray-700/50"
                  }`}
                  onClick={() => {
                    if (!notification.read) {
                      markAsRead({ notificationId: notification._id });
                    }
                  }}
                >
                  <div className="flex justify-between items-start">
                    <p
                      className={`text-sm ${
                        notification.read
                          ? "text-gray-600 dark:text-gray-400"
                          : "text-gray-900 dark:text-gray-100"
                      }`}
                    >
                      {notification.message}
                    </p>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {formatTime(notification._creationTime)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
