import { useState } from "react";
import { useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { useLanguage } from "./LanguageContext";
import { translations } from "./lib/translations";

export function SignInForm() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  
  const signIn = useAction(api.auth.signIn);
  const signUp = useAction(api.auth.signUp);
  
  const { language } = useLanguage();
  const t = translations[language];

  const validateEmail = (email: string) => {
    const validDomains = ['gmail.com', 'hotmail.com'];
    const domain = email.split('@')[1];
    return validDomains.includes(domain);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (isSignUp) {
      if (!name.trim()) {
        setError(t.nameRequired);
        return;
      }
      if (!validateEmail(email)) {
        setError(t.invalidEmail);
        return;
      }
      if (password.length < 8) {
        setError(t.passwordTooShort);
        return;
      }
      try {
        await signUp({ name, email, password });
      } catch (error) {
        setError(t.signUpError);
      }
    } else {
      try {
        await signIn({ email, password });
      } catch (error) {
        setError(t.signInError);
      }
    }
  };

  return (
    <div className="max-w-md mx-auto mt-8">
      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-6 text-center">
          {isSignUp ? t.signUp : t.signIn}
        </h2>
        
        {isSignUp && (
          <div className="mb-4">
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">
              {t.name}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder={t.enterName}
            />
          </div>
        )}

        <div className="mb-4">
          <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">
            {t.email}
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            placeholder={t.enterEmail}
          />
        </div>

        <div className="mb-6">
          <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">
            {t.password}
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            placeholder={t.enterPassword}
          />
        </div>

        {error && (
          <div className="mb-4 text-red-500 text-sm text-center">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-indigo-500 text-white p-2 rounded hover:bg-indigo-600 transition-colors"
        >
          {isSignUp ? t.signUp : t.signIn}
        </button>

        <div className="mt-4 text-center">
          <button
            type="button"
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-indigo-500 hover:text-indigo-600 text-sm"
          >
            {isSignUp ? t.alreadyHaveAccount : t.needAccount}
          </button>
        </div>
      </form>
    </div>
  );
}
