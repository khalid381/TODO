import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  users: defineTable({
    name: v.string(),
    email: v.string(),
    password: v.string(), // In a real app, this would be a hashed password
  }).index("email", ["email"]),
  tasks: defineTable({
    title: v.string(),
    status: v.string(),
    userId: v.id("users"),
    dueDate: v.optional(v.number()),
    reminderEnabled: v.optional(v.boolean()),
    startTime: v.optional(v.number()),
    completionTime: v.optional(v.number()),
  }).index("by_user", ["userId"]),
  notifications: defineTable({
    userId: v.id("users"),
    taskId: v.id("tasks"),
    message: v.string(),
    read: v.boolean(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
