export function playNotificationSound() {
  const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
  audio.play().catch(error => {
    // تجاهل أخطاء التشغيل التلقائي في بعض المتصفحات
    console.log("Could not play notification sound:", error);
  });
}
