import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { useState } from "react";
import { Id } from "../convex/_generated/dataModel";
import { toast } from "sonner";
import { useLanguage } from "./LanguageContext";
import { translations } from "./lib/translations";

interface Task {
  _id: Id<"tasks">;
  title: string;
  description?: string;
  status: string;
  startTime?: number;
  endTime?: number;
  dueDate?: number;
  reminder?: boolean;
}

export function KanbanBoard() {
  const { language } = useLanguage();
  const t = translations[language];
  
  const tasks = useQuery(api.tasks.get) || [];
  const create = useMutation(api.tasks.create);
  const updateStatus = useMutation(api.tasks.updateStatus);
  const remove = useMutation(api.tasks.remove);
  const [newTask, setNewTask] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [reminder, setReminder] = useState(false);

  const columns = {
    todo: {
      title: t.newTasks,
      tasks: tasks.filter((t: Task) => t.status === "todo"),
    },
    inProgress: {
      title: t.inProgress,
      tasks: tasks.filter((t: Task) => t.status === "inProgress"),
    },
    done: {
      title: t.done,
      tasks: tasks.filter((t: Task) => t.status === "done"),
    },
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.types[0] === 'application/convex-task') {
      e.dataTransfer.dropEffect = 'move';
    }
  };

  const handleDrop = async (e: React.DragEvent, status: string) => {
    e.preventDefault();
    try {
      const taskId = e.dataTransfer.getData("application/convex-task") as Id<"tasks">;
      if (!taskId) return;
      
      const order = columns[status as keyof typeof columns].tasks.length;
      await updateStatus({ taskId, status, order });
      toast.success(language === 'ar' ? "تم نقل المهمة بنجاح" : "Task moved successfully");
    } catch (error) {
      toast.error(language === 'ar' ? "حدث خطأ أثناء نقل المهمة" : "Error moving task");
      console.error(error);
    }
  };

  const handleDragStart = (e: React.DragEvent, taskId: Id<"tasks">) => {
    e.dataTransfer.setData("application/convex-task", taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    
    try {
      const dueDateValue = dueDate ? new Date(dueDate).getTime() : undefined;
      
      await create({
        title: newTask,
        status: "todo",
        dueDate: dueDateValue,
        reminder: dueDateValue ? reminder : undefined,
      });
      setNewTask("");
      setDueDate("");
      setReminder(false);
      toast.success(language === 'ar' ? "تمت إضافة المهمة" : "Task added successfully");
    } catch (error) {
      toast.error(language === 'ar' ? "حدث خطأ أثناء إضافة المهمة" : "Error adding task");
      console.error(error);
    }
  };

  const handleRemove = async (taskId: Id<"tasks">) => {
    try {
      await remove({ taskId });
      toast.success(language === 'ar' ? "تم حذف المهمة" : "Task deleted successfully");
    } catch (error) {
      toast.error(language === 'ar' ? "حدث خطأ أثناء حذف المهمة" : "Error deleting task");
      console.error(error);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDuration = (startTime?: number, endTime?: number) => {
    if (!startTime) return t.unknownTime;
    const end = endTime || Date.now();
    const duration = end - startTime;
    const hours = Math.floor(duration / (1000 * 60 * 60));
    const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((duration % (1000 * 60)) / 1000);
    
    if (hours > 0) {
      return `${hours} ${t.hours} ${t.and} ${minutes} ${t.minutes}`;
    } else if (minutes > 0) {
      return `${minutes} ${t.minutes} ${t.and} ${seconds} ${t.seconds}`;
    } else {
      return `${seconds} ${t.seconds}`;
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <form onSubmit={handleCreate} className="flex flex-col gap-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder={t.addNewTask}
            className="flex-1 p-2 border rounded dark:bg-gray-800 dark:border-gray-700 dark:text-white"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-indigo-500 text-white rounded hover:bg-indigo-600 transition-colors"
          >
            {t.addTask}
          </button>
        </div>
        <div className="flex gap-4 items-center">
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-600 dark:text-gray-400">{t.dueDate}:</label>
            <input
              type="datetime-local"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="p-2 border rounded dark:bg-gray-800 dark:border-gray-700 dark:text-white text-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={reminder}
              onChange={(e) => setReminder(e.target.checked)}
              className="rounded border-gray-300 dark:border-gray-600"
              id="reminder"
            />
            <label
              htmlFor="reminder"
              className="text-sm text-gray-600 dark:text-gray-400"
            >
              {t.enableReminder}
            </label>
          </div>
        </div>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Object.entries(columns).map(([status, column]) => (
          <div
            key={status}
            className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg"
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, status)}
          >
            <h3 className="font-semibold mb-4 text-gray-700 dark:text-gray-300">
              {column.title} ({column.tasks.length})
            </h3>
            <div className="flex flex-col gap-2">
              {column.tasks.map((task: Task) => (
                <div
                  key={task._id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, task._id)}
                  className="bg-white dark:bg-gray-700 p-3 rounded shadow-sm cursor-move group"
                >
                  <div className="flex justify-between items-start">
                    <p className="text-gray-800 dark:text-gray-200">{task.title}</p>
                    <button
                      onClick={() => handleRemove(task._id)}
                      className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-600 transition-opacity"
                    >
                      ×
                    </button>
                  </div>
                  {task.description && (
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      {task.description}
                    </p>
                  )}
                  {task.startTime && (
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                      <span>⏱️ {t.duration}: {formatDuration(task.startTime, task.endTime)}</span>
                    </div>
                  )}
                  {task.dueDate && (
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                      <span>🕒</span>
                      <span>{formatDate(task.dueDate)}</span>
                      {task.reminder && <span>🔔</span>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
