import { v } from "convex/values";
import { action } from "./_generated/server";
import { internal } from "./_generated/api";

export const signIn = action({
  args: {
    email: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await ctx.runQuery(internal.users.getUserByEmail, {
      email: args.email,
    });
    
    if (!user || user.password !== args.password) {
      throw new Error("Invalid email or password");
    }

    return user._id;
  },
});

export const signUp = action({
  args: {
    name: v.string(),
    email: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    // Check if user already exists
    const existingUser = await ctx.runQuery(internal.users.getUserByEmail, {
      email: args.email,
    });
    
    if (existingUser) {
      throw new Error("User already exists");
    }

    // Create new user
    const userId = await ctx.runMutation(internal.users.createUser, {
      name: args.name,
      email: args.email,
      password: args.password, // In a real app, hash this password!
    });

    return userId;
  },
});
