import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { internal } from "./_generated/api";

export const getTasks = query({
  args: {
    userId: v.id("users"),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { userId, status } = args;
    let taskQuery = ctx.db
      .query("tasks")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (status) {
      taskQuery = taskQuery.filter((q) => q.eq("status", status));
    }

    return await taskQuery.collect();
  },
});

export const createTask = mutation({
  args: {
    userId: v.id("users"),
    title: v.string(),
    dueDate: v.optional(v.number()),
    reminderEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const taskId = await ctx.db.insert("tasks", {
      userId: args.userId,
      title: args.title,
      status: "new",
      dueDate: args.dueDate,
      reminderEnabled: args.reminderEnabled,
      startTime: null,
    });

    return taskId;
  },
});

export const updateStatus = mutation({
  args: {
    taskId: v.id("tasks"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const task = await ctx.db.get(args.taskId);
    if (!task) {
      throw new Error("Task not found");
    }

    const updates: any = {
      status: args.status,
    };

    if (args.status === "inProgress" && !task.startTime) {
      updates.startTime = Date.now();
    } else if (args.status === "done" && !task.completionTime) {
      updates.completionTime = Date.now();
      
      // Calculate duration
      if (task.startTime) {
        const duration = updates.completionTime - task.startTime;
        
        // Create completion notification
        await ctx.db.insert("notifications", {
          userId: task.userId,
          taskId: args.taskId,
          message: `Task "${task.title}" completed in ${Math.round(duration / 1000)} seconds`,
          read: false,
        });
      }
    }

    await ctx.db.patch(args.taskId, updates);
  },
});

export const getNotifications = query({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .order("desc")
      .collect();
  },
});

export const markNotificationAsRead = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.notificationId, {
      read: true,
    });
  },
});
