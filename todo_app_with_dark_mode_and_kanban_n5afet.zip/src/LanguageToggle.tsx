import { useLanguage } from './LanguageContext';
import { translations } from './lib/translations';

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();
  
  return (
    <button
      onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
      className="px-3 py-1 text-sm rounded-md bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      {translations[language].language}
    </button>
  );
}
