import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { translations } from './lib/translations';

export function DarkModeToggle() {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <button
      onClick={() => setDarkMode(!darkMode)}
      className="px-3 py-1 text-sm rounded-md bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center gap-2"
    >
      {darkMode ? '🌙' : '☀️'}
      <span>{darkMode ? t.lightMode : t.darkMode}</span>
    </button>
  );
}
